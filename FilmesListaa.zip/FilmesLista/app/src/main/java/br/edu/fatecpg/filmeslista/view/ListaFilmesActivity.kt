package br.edu.fatecpg.filmeslista.view

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import br.edu.fatecpg.filmeslista.R
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import br.edu.fatecpg.filmeslista.adapter.FilmesAdapter
import br.edu.fatecpg.filmeslista.dao.FilmesDao


class ListaFilmesActivity : AppCompatActivity() {
    private val dao = FilmesDao()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_filmes)

        val recyclerView = findViewById<RecyclerView>(R.id.Lista_filme)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = FilmesAdapter(dao.consultarFilmes())
    }
}