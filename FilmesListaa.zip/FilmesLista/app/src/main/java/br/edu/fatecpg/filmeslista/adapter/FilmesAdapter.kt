package br.edu.fatecpg.filmeslista.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import br.edu.fatecpg.filmeslista.R
import br.edu.fatecpg.filmeslista.model.Filmes


class FilmesAdapter(private val filmes: List<Filmes>) : RecyclerView.Adapter<FilmesAdapter.FilmesViewHolder>() {

    class FilmesViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val titulo: TextView = view.findViewById(R.id.txt_titulofilme)
        val diretor: TextView = view.findViewById(R.id.txt_diretorfilme)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FilmesViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_filme, parent, false)
        return FilmesViewHolder(view)
    }

    override fun onBindViewHolder(holder: FilmesViewHolder, position: Int) {
        val filme = filmes[position]
        holder.titulo.text = "Título: ${filme.Titulo}"
        holder.diretor.text = "Diretor: ${filme.Diretor}"
    }

    override fun getItemCount() = filmes.size
}