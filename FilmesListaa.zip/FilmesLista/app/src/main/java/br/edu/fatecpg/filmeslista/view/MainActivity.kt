package br.edu.fatecpg.filmeslista.view

import android.content.Intent
import br.edu.fatecpg.filmeslista.R
import br.edu.fatecpg.filmeslista.dao.FilmesDao
import br.edu.fatecpg.filmeslista.model.Filmes
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    private val dao = FilmesDao()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val edtTitulo = findViewById<EditText>(R.id.edt_titulo)
        val edtDiretor = findViewById<EditText>(R.id.edt_diretor)
        val btnAdicionar = findViewById<Button>(R.id.btn_adicionar)
        val fabLista = findViewById<FloatingActionButton>(R.id.fab_lista)

        btnAdicionar.setOnClickListener {
            val titulo = edtTitulo.text.toString()
            val diretor = edtDiretor.text.toString()

            if (titulo.isNotBlank() && diretor.isNotBlank()) {
                dao.adicionarFilme(Filmes(titulo, diretor))
                edtTitulo.text.clear()
                edtDiretor.text.clear()
                Toast.makeText(this, "Filme adicionado!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show()
            }
        }

        fabLista.setOnClickListener {
            val intent = Intent(this, ListaFilmesActivity::class.java)
            startActivity(intent)
    }
}
}