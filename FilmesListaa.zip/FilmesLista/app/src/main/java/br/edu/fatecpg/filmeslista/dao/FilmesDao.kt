package br.edu.fatecpg.filmeslista.dao

import br.edu.fatecpg.filmeslista.model.Filmes

class FilmesDao {
    companion object{
        private val filmes:MutableList<Filmes> = mutableListOf()
    }

    fun adicionarFilme(filme: Filmes){
        filmes.add(filme)
    }

    fun consultarFilmes(): List<Filmes> {
        return filmes

    }
}