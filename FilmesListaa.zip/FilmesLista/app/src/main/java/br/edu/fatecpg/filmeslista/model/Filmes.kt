package br.edu.fatecpg.filmeslista.model

data class Filmes(val Titulo:String = "",
                  val Diretor:String = "")
